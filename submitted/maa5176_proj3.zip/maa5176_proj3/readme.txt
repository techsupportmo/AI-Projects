Name: Mohammed Ahmed
ID #: 1001655176


--------------------- TASK 1 -------------------------------------------------------------

Programming Language Used: Python


Code Structure:
# Function: WriteResults()
# Purpose:  Write the probabilities (same output as print statements) to results.txt file
# Input:    Array with h values, Cherry next probability, Lime next probability
# Output:   Nothing, only print statements

# Function: PrintProbability()
# Purpose:  Print out probability values to the screen
# Input:    Array with h values, Cherry next probability, Lime next probability
# Output:   Nothing, only print statements


-----------------------------------------------------------------------------------------

--------------------- TASK 2 -------------------------------------------------------------

Programming Language Used: Python


Code Structure:

- Arrays to store probability values
- Dictionaries to store specific T/F values



------------------------------------------------------------------------------------------